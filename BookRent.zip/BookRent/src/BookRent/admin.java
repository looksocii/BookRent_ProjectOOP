package BookRent;

import java.awt.Color;
import java.awt.geom.RoundRectangle2D;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

public class admin extends javax.swing.JFrame {

    ShareMethod shareMethod = new ShareMethod();
    /**
     * Creates new form admin
     */
    public admin() {
        setUndecorated(true);
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        setShape(new RoundRectangle2D.Double(0,0, 1200,700, 50,50));
        admin_welcome_name.setText("Admin");
        try {
            setTable();
        } catch (IOException ex) {
            Logger.getLogger(admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void setTable() throws IOException{
        admin_library_order.setModel(new javax.swing.table.DefaultTableModel(shareMethod.getBookStoreData(),
                                new String[] { "No", "Image", "ID", "BookName", "Author", "Category", "Quantity",
                                                "Price" }) {
                        Class[] types = new Class[] { java.lang.String.class, javax.swing.Icon.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class, };
                        boolean[] canEdit = new boolean[] { false, false, false, false, false, false, false, false };

                        public Class getColumnClass(int columnIndex) {
                                return types[columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                                return canEdit[columnIndex];
                        }
                });
                admin_library_order.setRowHeight(100);
                
        admin_rent_order.setModel(new javax.swing.table.DefaultTableModel(
                                shareMethod.getHistoryDataRentForStaffAdmin(), new String[] { "No", "Username",
                                                "BookName", "ID", "Price", "Time", "ReturnTime", "status" }) {
                        Class[] types = new Class[] { java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class };
                        boolean[] canEdit = new boolean[] { false, false, false, false, false, false, false, false,
                                        false };

                        public Class getColumnClass(int columnIndex) {
                                return types[columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                                return canEdit[columnIndex];
                        }
                });
        
        admin_return_order.setModel(new javax.swing.table.DefaultTableModel(
                                shareMethod.getHistoryDataReturnForStaffAdmin(), new String[] { "No", "Username",
                                                "BookName", "ID", "Price", "Time", "ReturnTime", "status" }) {
                        Class[] types = new Class[] { java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class };
                        boolean[] canEdit = new boolean[] { false, false, false, false, false, false, false, false,
                                        false };

                        public Class getColumnClass(int columnIndex) {
                                return types[columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                                return canEdit[columnIndex];
                        }
                });
        
        admin_user_order.setModel(new javax.swing.table.DefaultTableModel(shareMethod.getCustomerData(),
                                new String[] { "No", "Username", "Firstname", "Lastname", "OutstandingBalance",
                                                "BookBalance" }) {
                        Class[] types = new Class[] { java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class };
                        boolean[] canEdit = new boolean[] { false, false, false, false, false, false };

                        public Class getColumnClass(int columnIndex) {
                                return types[columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                                return canEdit[columnIndex];
                        }
                });
        
        admin_staff_order.setModel(new javax.swing.table.DefaultTableModel(shareMethod.getPersonnelData(),
                                new String[] { "No", "Username", "Firstname", "Lastname", "JobPosition" }) {
                        Class[] types = new Class[] { java.lang.String.class, java.lang.String.class,
                                        java.lang.String.class, java.lang.String.class, java.lang.String.class };
                        boolean[] canEdit = new boolean[] { false, false, false, false, false, false };

                        public Class getColumnClass(int columnIndex) {
                                return types[columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                                return canEdit[columnIndex];
                        }
                });
                // edited
                admin_staff_scroll.setViewportView(admin_staff_order);
                if (admin_staff_order.getColumnModel().getColumnCount() > 0) {
                        admin_staff_order.getColumnModel().getColumn(0).setMinWidth(50);
                        admin_staff_order.getColumnModel().getColumn(0).setMaxWidth(60);
                        admin_staff_order.getColumnModel().getColumn(4).setMinWidth(90);
                        admin_staff_order.getColumnModel().getColumn(4).setMaxWidth(100);
                }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        admin_main = new javax.swing.JPanel();
        admin_sidetab = new javax.swing.JPanel();
        admin_tab_welcome = new javax.swing.JPanel();
        admin_tab_welcomelogo = new javax.swing.JLabel();
        admin_tab_library = new javax.swing.JPanel();
        admin_txt_library = new javax.swing.JLabel();
        admin_tab_librarylogo = new javax.swing.JLabel();
        admin_tab_rent = new javax.swing.JPanel();
        admin_txt_rent = new javax.swing.JLabel();
        admin_tab_rentlogo = new javax.swing.JLabel();
        admin_tab_return = new javax.swing.JPanel();
        admin_txt_return = new javax.swing.JLabel();
        admin_tab_returnlogo = new javax.swing.JLabel();
        admin_tab_user = new javax.swing.JPanel();
        admin_txt_user = new javax.swing.JLabel();
        admin_tab_userlogo = new javax.swing.JLabel();
        admin_tab_staff = new javax.swing.JPanel();
        admin_txt_staff = new javax.swing.JLabel();
        admin_tab_stafflogo = new javax.swing.JLabel();
        admin_tab_empty1 = new javax.swing.JPanel();
        admin_tab_logout = new javax.swing.JPanel();
        admin_txt_logout = new javax.swing.JLabel();
        admin_tab_logoutlogo = new javax.swing.JLabel();
        admin_multipanel = new javax.swing.JPanel();
        admin_panel_welcome = new javax.swing.JPanel();
        admin_welcome_welcome = new javax.swing.JLabel();
        admin_welcome_bookrent = new javax.swing.JLabel();
        admin_welcome_name = new javax.swing.JLabel();
        admin_welcome_logo = new javax.swing.JLabel();
        admin_panel_library = new javax.swing.JPanel();
        admin_library_search = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        admin_library_order = new javax.swing.JTable();
        admin_liblrary_add = new javax.swing.JPanel();
        admin_add_id = new javax.swing.JTextField();
        admin_add_name = new javax.swing.JTextField();
        admin_add_type = new javax.swing.JTextField();
        admin_add_quantity = new javax.swing.JTextField();
        admin_add_price = new javax.swing.JTextField();
        admin_add_buttonadd = new javax.swing.JButton();
        admin_add_buttonimage = new javax.swing.JButton();
        admin_add_image = new javax.swing.JLabel();
        admin_add_buttonedit = new javax.swing.JButton();
        admin_add_buttondelete = new javax.swing.JButton();
        admin_panel_rent = new javax.swing.JPanel();
        admin_rent_search = new javax.swing.JTextField();
        admin_rent_jscroll = new javax.swing.JScrollPane();
        admin_rent_order = new javax.swing.JTable();
        admin_panel_returnbook = new javax.swing.JPanel();
        admin_rent_search1 = new javax.swing.JTextField();
        admin_return_jscroll = new javax.swing.JScrollPane();
        admin_return_order = new javax.swing.JTable();
        admin_panel_user = new javax.swing.JPanel();
        admin_user_search = new javax.swing.JTextField();
        admin_user_scroll = new javax.swing.JScrollPane();
        admin_user_order = new javax.swing.JTable();
        admin_panel_staff = new javax.swing.JPanel();
        admin_staff_search = new javax.swing.JTextField();
        admin_staff_scroll = new javax.swing.JScrollPane();
        admin_staff_order = new javax.swing.JTable();
        admin_staff_add = new javax.swing.JPanel();
        admin_staff_addusername = new javax.swing.JTextField();
        admin_staff_addpassword = new javax.swing.JPasswordField();
        admin_staff_addfirstname = new javax.swing.JTextField();
        admin_staff_addlastname = new javax.swing.JTextField();
        admin_staff_addbuttonadd = new javax.swing.JButton();
        admin_staff_buttonedit = new javax.swing.JButton();
        admin_staff_buttondelete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("BookRent");
        setResizable(false);

        admin_main.setBackground(new java.awt.Color(255, 255, 153));
        admin_main.setMaximumSize(new java.awt.Dimension(1200, 700));
        admin_main.setMinimumSize(new java.awt.Dimension(1200, 700));
        admin_main.setPreferredSize(new java.awt.Dimension(1200, 700));

        admin_sidetab.setBackground(new java.awt.Color(255, 204, 0));
        admin_sidetab.setLayout(new javax.swing.BoxLayout(admin_sidetab, javax.swing.BoxLayout.PAGE_AXIS));

        admin_tab_welcome.setBackground(new java.awt.Color(255, 102, 0));
        admin_tab_welcome.setPreferredSize(new java.awt.Dimension(0, 140));
        admin_tab_welcome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
        });

        admin_tab_welcomelogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/welcome.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_welcomeLayout = new javax.swing.GroupLayout(admin_tab_welcome);
        admin_tab_welcome.setLayout(admin_tab_welcomeLayout);
        admin_tab_welcomeLayout.setHorizontalGroup(
            admin_tab_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_tab_welcomeLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(admin_tab_welcomelogo)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        admin_tab_welcomeLayout.setVerticalGroup(
            admin_tab_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_tab_welcomelogo, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_welcome);

        admin_tab_library.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_library.setPreferredSize(new java.awt.Dimension(200, 80));
        admin_tab_library.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_library.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_library.setText("Library");

        admin_tab_librarylogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_librarylogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/library.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_libraryLayout = new javax.swing.GroupLayout(admin_tab_library);
        admin_tab_library.setLayout(admin_tab_libraryLayout);
        admin_tab_libraryLayout.setHorizontalGroup(
            admin_tab_libraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_tab_libraryLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(admin_tab_librarylogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_library)
                .addGap(23, 23, 23))
        );
        admin_tab_libraryLayout.setVerticalGroup(
            admin_tab_libraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_tab_librarylogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
            .addComponent(admin_txt_library, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_library);

        admin_tab_rent.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_rent.setPreferredSize(new java.awt.Dimension(200, 80));
        admin_tab_rent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_rent.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_rent.setText("Rent");

        admin_tab_rentlogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_rentlogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/rent.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_rentLayout = new javax.swing.GroupLayout(admin_tab_rent);
        admin_tab_rent.setLayout(admin_tab_rentLayout);
        admin_tab_rentLayout.setHorizontalGroup(
            admin_tab_rentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_tab_rentLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(admin_tab_rentlogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_rent)
                .addContainerGap(49, Short.MAX_VALUE))
        );
        admin_tab_rentLayout.setVerticalGroup(
            admin_tab_rentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_txt_rent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admin_tab_rentlogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_rent);

        admin_tab_return.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_return.setPreferredSize(new java.awt.Dimension(200, 80));
        admin_tab_return.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_return.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_return.setText("Return");

        admin_tab_returnlogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_returnlogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/return.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_returnLayout = new javax.swing.GroupLayout(admin_tab_return);
        admin_tab_return.setLayout(admin_tab_returnLayout);
        admin_tab_returnLayout.setHorizontalGroup(
            admin_tab_returnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_tab_returnLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(admin_tab_returnlogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_return)
                .addGap(29, 29, 29))
        );
        admin_tab_returnLayout.setVerticalGroup(
            admin_tab_returnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_txt_return, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admin_tab_returnlogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_return);

        admin_tab_user.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_user.setPreferredSize(new java.awt.Dimension(200, 80));
        admin_tab_user.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_user.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_user.setText("User");

        admin_tab_userlogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_userlogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/user.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_userLayout = new javax.swing.GroupLayout(admin_tab_user);
        admin_tab_user.setLayout(admin_tab_userLayout);
        admin_tab_userLayout.setHorizontalGroup(
            admin_tab_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_tab_userLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(admin_tab_userlogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_user)
                .addGap(50, 50, 50))
        );
        admin_tab_userLayout.setVerticalGroup(
            admin_tab_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_txt_user, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admin_tab_userlogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_user);

        admin_tab_staff.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_staff.setPreferredSize(new java.awt.Dimension(200, 80));
        admin_tab_staff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_staff.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_staff.setText("Staff");

        admin_tab_stafflogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_stafflogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/staff.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_staffLayout = new javax.swing.GroupLayout(admin_tab_staff);
        admin_tab_staff.setLayout(admin_tab_staffLayout);
        admin_tab_staffLayout.setHorizontalGroup(
            admin_tab_staffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_tab_staffLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(admin_tab_stafflogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_staff, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        admin_tab_staffLayout.setVerticalGroup(
            admin_tab_staffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_txt_staff, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admin_tab_stafflogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_staff);

        admin_tab_empty1.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_empty1.setPreferredSize(new java.awt.Dimension(200, 80));

        javax.swing.GroupLayout admin_tab_empty1Layout = new javax.swing.GroupLayout(admin_tab_empty1);
        admin_tab_empty1.setLayout(admin_tab_empty1Layout);
        admin_tab_empty1Layout.setHorizontalGroup(
            admin_tab_empty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 200, Short.MAX_VALUE)
        );
        admin_tab_empty1Layout.setVerticalGroup(
            admin_tab_empty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_empty1);

        admin_tab_logout.setBackground(new java.awt.Color(255, 153, 0));
        admin_tab_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                admin_mouseclicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                admin_mouseentered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                admin_mouseexited(evt);
            }
        });

        admin_txt_logout.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_txt_logout.setText("Logout");

        admin_tab_logoutlogo.setFont(new java.awt.Font("Angsana New", 0, 36)); // NOI18N
        admin_tab_logoutlogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logout.png"))); // NOI18N

        javax.swing.GroupLayout admin_tab_logoutLayout = new javax.swing.GroupLayout(admin_tab_logout);
        admin_tab_logout.setLayout(admin_tab_logoutLayout);
        admin_tab_logoutLayout.setHorizontalGroup(
            admin_tab_logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_tab_logoutLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(admin_tab_logoutlogo)
                .addGap(18, 18, 18)
                .addComponent(admin_txt_logout)
                .addGap(25, 25, 25))
        );
        admin_tab_logoutLayout.setVerticalGroup(
            admin_tab_logoutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_txt_logout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(admin_tab_logoutlogo, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        admin_sidetab.add(admin_tab_logout);

        admin_multipanel.setBackground(new java.awt.Color(255, 255, 153));
        admin_multipanel.setLayout(new java.awt.CardLayout());

        admin_panel_welcome.setBackground(new java.awt.Color(255, 204, 0));
        admin_panel_welcome.setPreferredSize(new java.awt.Dimension(800, 700));

        admin_welcome_welcome.setFont(new java.awt.Font("Banaue", 1, 90)); // NOI18N
        admin_welcome_welcome.setText("WELCOME");

        admin_welcome_bookrent.setFont(new java.awt.Font("Banaue", 0, 54)); // NOI18N
        admin_welcome_bookrent.setText("BookRent");

        admin_welcome_name.setFont(new java.awt.Font("TH SarabunPSK", 0, 48)); // NOI18N
        admin_welcome_name.setText("xxxxxxxxxxxxxxxxxxxxx");

        admin_welcome_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logo.png"))); // NOI18N

        javax.swing.GroupLayout admin_panel_welcomeLayout = new javax.swing.GroupLayout(admin_panel_welcome);
        admin_panel_welcome.setLayout(admin_panel_welcomeLayout);
        admin_panel_welcomeLayout.setHorizontalGroup(
            admin_panel_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_panel_welcomeLayout.createSequentialGroup()
                .addGap(282, 282, 282)
                .addComponent(admin_welcome_welcome)
                .addGap(337, 337, 337))
            .addGroup(admin_panel_welcomeLayout.createSequentialGroup()
                .addGroup(admin_panel_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(admin_panel_welcomeLayout.createSequentialGroup()
                        .addGap(332, 332, 332)
                        .addComponent(admin_welcome_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(admin_welcome_bookrent))
                    .addGroup(admin_panel_welcomeLayout.createSequentialGroup()
                        .addGap(368, 368, 368)
                        .addComponent(admin_welcome_name)))
                .addContainerGap())
        );
        admin_panel_welcomeLayout.setVerticalGroup(
            admin_panel_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_welcomeLayout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addComponent(admin_welcome_welcome)
                .addGap(43, 43, 43)
                .addGroup(admin_panel_welcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(admin_panel_welcomeLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(admin_welcome_bookrent))
                    .addComponent(admin_welcome_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(admin_welcome_name)
                .addContainerGap())
        );

        admin_multipanel.add(admin_panel_welcome, "card6");

        admin_panel_library.setBackground(new java.awt.Color(255, 204, 0));
        admin_panel_library.setPreferredSize(new java.awt.Dimension(800, 700));

        admin_library_search.setFont(new java.awt.Font("Angsana New", 0, 30)); // NOI18N

        admin_library_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Image", "ID", "Name", "Type", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(admin_library_order);
        if (admin_library_order.getColumnModel().getColumnCount() > 0) {
            admin_library_order.getColumnModel().getColumn(0).setMinWidth(50);
            admin_library_order.getColumnModel().getColumn(0).setMaxWidth(60);
            admin_library_order.getColumnModel().getColumn(1).setMinWidth(180);
            admin_library_order.getColumnModel().getColumn(1).setMaxWidth(190);
            admin_library_order.getColumnModel().getColumn(2).setMinWidth(150);
            admin_library_order.getColumnModel().getColumn(2).setMaxWidth(160);
            admin_library_order.getColumnModel().getColumn(5).setMinWidth(80);
            admin_library_order.getColumnModel().getColumn(5).setMaxWidth(90);
        }

        admin_liblrary_add.setBackground(new java.awt.Color(255, 102, 0));

        admin_add_id.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_id.setText("ID");

        admin_add_name.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_name.setText("Name");

        admin_add_type.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_type.setText("Type");

        admin_add_quantity.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_quantity.setText("Quantity");

        admin_add_price.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_price.setText("Price");

        admin_add_buttonadd.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_buttonadd.setText("ADD");

        admin_add_buttonimage.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_buttonimage.setText("Image");
        admin_add_buttonimage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admin_add_buttonimageActionPerformed(evt);
            }
        });

        admin_add_image.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_image.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        admin_add_buttonedit.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_buttonedit.setText("Edit");

        admin_add_buttondelete.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_add_buttondelete.setText("Delete");

        javax.swing.GroupLayout admin_liblrary_addLayout = new javax.swing.GroupLayout(admin_liblrary_add);
        admin_liblrary_add.setLayout(admin_liblrary_addLayout);
        admin_liblrary_addLayout.setHorizontalGroup(
            admin_liblrary_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_liblrary_addLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(admin_add_image, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_buttonimage)
                .addGap(18, 18, 18)
                .addComponent(admin_add_id, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_name, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_type, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_price, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_add_buttonadd)
                .addGap(18, 18, 18)
                .addComponent(admin_add_buttonedit, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(admin_add_buttondelete, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(141, Short.MAX_VALUE))
        );
        admin_liblrary_addLayout.setVerticalGroup(
            admin_liblrary_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_liblrary_addLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(admin_liblrary_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(admin_add_quantity)
                    .addComponent(admin_add_type)
                    .addComponent(admin_add_name)
                    .addComponent(admin_add_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(admin_add_price, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(admin_add_buttonadd)
                    .addComponent(admin_add_buttonimage)
                    .addComponent(admin_add_buttonedit)
                    .addComponent(admin_add_buttondelete))
                .addGap(26, 26, 26))
            .addComponent(admin_add_image, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout admin_panel_libraryLayout = new javax.swing.GroupLayout(admin_panel_library);
        admin_panel_library.setLayout(admin_panel_libraryLayout);
        admin_panel_libraryLayout.setHorizontalGroup(
            admin_panel_libraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_liblrary_add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(admin_panel_libraryLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(admin_panel_libraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 948, Short.MAX_VALUE)
                    .addComponent(admin_library_search))
                .addContainerGap())
        );
        admin_panel_libraryLayout.setVerticalGroup(
            admin_panel_libraryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_panel_libraryLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(admin_library_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 477, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(admin_liblrary_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        admin_multipanel.add(admin_panel_library, "card2");

        admin_panel_rent.setBackground(new java.awt.Color(255, 204, 0));

        admin_rent_search.setFont(new java.awt.Font("Angsana New", 0, 30)); // NOI18N

        admin_rent_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Image", "User", "ID", "Name", "Type", "Quantity", "Price", "Rent"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        admin_rent_jscroll.setViewportView(admin_rent_order);
        if (admin_rent_order.getColumnModel().getColumnCount() > 0) {
            admin_rent_order.getColumnModel().getColumn(0).setMinWidth(50);
            admin_rent_order.getColumnModel().getColumn(0).setMaxWidth(60);
            admin_rent_order.getColumnModel().getColumn(5).setHeaderValue("Type");
            admin_rent_order.getColumnModel().getColumn(6).setMinWidth(60);
            admin_rent_order.getColumnModel().getColumn(6).setMaxWidth(70);
            admin_rent_order.getColumnModel().getColumn(6).setHeaderValue("Quantity");
            admin_rent_order.getColumnModel().getColumn(7).setMinWidth(90);
            admin_rent_order.getColumnModel().getColumn(7).setMaxWidth(100);
        }

        javax.swing.GroupLayout admin_panel_rentLayout = new javax.swing.GroupLayout(admin_panel_rent);
        admin_panel_rent.setLayout(admin_panel_rentLayout);
        admin_panel_rentLayout.setHorizontalGroup(
            admin_panel_rentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_panel_rentLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(admin_panel_rentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(admin_rent_search)
                    .addComponent(admin_rent_jscroll, javax.swing.GroupLayout.DEFAULT_SIZE, 948, Short.MAX_VALUE))
                .addGap(26, 26, 26))
        );
        admin_panel_rentLayout.setVerticalGroup(
            admin_panel_rentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_rentLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(admin_rent_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(admin_rent_jscroll, javax.swing.GroupLayout.PREFERRED_SIZE, 591, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        admin_multipanel.add(admin_panel_rent, "card3");

        admin_panel_returnbook.setBackground(new java.awt.Color(255, 204, 0));
        admin_panel_returnbook.setPreferredSize(new java.awt.Dimension(800, 700));

        admin_rent_search1.setFont(new java.awt.Font("Angsana New", 0, 30)); // NOI18N

        admin_return_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Image", "User", "ID", "Name", "Type", "Quantity", "Price", "Return"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        admin_return_jscroll.setViewportView(admin_return_order);
        if (admin_return_order.getColumnModel().getColumnCount() > 0) {
            admin_return_order.getColumnModel().getColumn(0).setMinWidth(50);
            admin_return_order.getColumnModel().getColumn(0).setMaxWidth(60);
            admin_return_order.getColumnModel().getColumn(5).setHeaderValue("Type");
            admin_return_order.getColumnModel().getColumn(6).setMinWidth(60);
            admin_return_order.getColumnModel().getColumn(6).setMaxWidth(70);
            admin_return_order.getColumnModel().getColumn(6).setHeaderValue("Quantity");
            admin_return_order.getColumnModel().getColumn(7).setMinWidth(90);
            admin_return_order.getColumnModel().getColumn(7).setMaxWidth(100);
        }

        javax.swing.GroupLayout admin_panel_returnbookLayout = new javax.swing.GroupLayout(admin_panel_returnbook);
        admin_panel_returnbook.setLayout(admin_panel_returnbookLayout);
        admin_panel_returnbookLayout.setHorizontalGroup(
            admin_panel_returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_returnbookLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(admin_panel_returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(admin_rent_search1)
                    .addComponent(admin_return_jscroll, javax.swing.GroupLayout.DEFAULT_SIZE, 948, Short.MAX_VALUE))
                .addGap(26, 26, 26))
        );
        admin_panel_returnbookLayout.setVerticalGroup(
            admin_panel_returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_returnbookLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(admin_rent_search1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(admin_return_jscroll, javax.swing.GroupLayout.PREFERRED_SIZE, 591, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        admin_multipanel.add(admin_panel_returnbook, "card4");

        admin_panel_user.setBackground(new java.awt.Color(255, 204, 0));

        admin_user_search.setFont(new java.awt.Font("Angsana New", 0, 30)); // NOI18N

        admin_user_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Username", "Firstname", "Lastname", "History"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        admin_user_scroll.setViewportView(admin_user_order);
        if (admin_user_order.getColumnModel().getColumnCount() > 0) {
            admin_user_order.getColumnModel().getColumn(0).setMinWidth(50);
            admin_user_order.getColumnModel().getColumn(0).setMaxWidth(60);
        }

        javax.swing.GroupLayout admin_panel_userLayout = new javax.swing.GroupLayout(admin_panel_user);
        admin_panel_user.setLayout(admin_panel_userLayout);
        admin_panel_userLayout.setHorizontalGroup(
            admin_panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_userLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(admin_panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(admin_user_scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 948, Short.MAX_VALUE)
                    .addComponent(admin_user_search))
                .addGap(26, 26, 26))
        );
        admin_panel_userLayout.setVerticalGroup(
            admin_panel_userLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_panel_userLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(admin_user_search, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(admin_user_scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 591, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        admin_multipanel.add(admin_panel_user, "card5");

        admin_panel_staff.setBackground(new java.awt.Color(255, 204, 0));

        admin_staff_search.setFont(new java.awt.Font("Angsana New", 0, 30)); // NOI18N

        admin_staff_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Username", "Firstname", "Lastname"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        admin_staff_order.setPreferredSize(new java.awt.Dimension(451, 0));
        admin_staff_scroll.setViewportView(admin_staff_order);
        if (admin_staff_order.getColumnModel().getColumnCount() > 0) {
            admin_staff_order.getColumnModel().getColumn(0).setMinWidth(50);
            admin_staff_order.getColumnModel().getColumn(0).setMaxWidth(60);
        }

        admin_staff_add.setBackground(new java.awt.Color(255, 102, 0));
        admin_staff_add.setPreferredSize(new java.awt.Dimension(1000, 85));

        admin_staff_addusername.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_addusername.setText("Username");

        admin_staff_addpassword.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        admin_staff_addpassword.setText("Password");

        admin_staff_addfirstname.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_addfirstname.setText("Firstname");

        admin_staff_addlastname.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_addlastname.setText("Lastname");

        admin_staff_addbuttonadd.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_addbuttonadd.setText("ADD");

        admin_staff_buttonedit.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_buttonedit.setText("Edit");

        admin_staff_buttondelete.setFont(new java.awt.Font("Angsana New", 0, 22)); // NOI18N
        admin_staff_buttondelete.setText("Delete");

        javax.swing.GroupLayout admin_staff_addLayout = new javax.swing.GroupLayout(admin_staff_add);
        admin_staff_add.setLayout(admin_staff_addLayout);
        admin_staff_addLayout.setHorizontalGroup(
            admin_staff_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_staff_addLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(admin_staff_addusername, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_addpassword, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_addfirstname, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_addlastname, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_addbuttonadd, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_buttonedit, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(admin_staff_buttondelete, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(120, Short.MAX_VALUE))
        );
        admin_staff_addLayout.setVerticalGroup(
            admin_staff_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_staff_addLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(admin_staff_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(admin_staff_addlastname)
                    .addGroup(admin_staff_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(admin_staff_addusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(admin_staff_addpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(admin_staff_addfirstname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(admin_staff_addLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(admin_staff_buttonedit)
                        .addComponent(admin_staff_buttondelete))
                    .addComponent(admin_staff_addbuttonadd))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout admin_panel_staffLayout = new javax.swing.GroupLayout(admin_panel_staff);
        admin_panel_staff.setLayout(admin_panel_staffLayout);
        admin_panel_staffLayout.setHorizontalGroup(
            admin_panel_staffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_staff_add, javax.swing.GroupLayout.DEFAULT_SIZE, 1089, Short.MAX_VALUE)
            .addGroup(admin_panel_staffLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(admin_panel_staffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(admin_staff_scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 948, Short.MAX_VALUE)
                    .addComponent(admin_staff_search))
                .addContainerGap())
        );
        admin_panel_staffLayout.setVerticalGroup(
            admin_panel_staffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admin_panel_staffLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(admin_staff_search, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(admin_staff_scroll, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(admin_staff_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        admin_multipanel.add(admin_panel_staff, "card7");

        javax.swing.GroupLayout admin_mainLayout = new javax.swing.GroupLayout(admin_main);
        admin_main.setLayout(admin_mainLayout);
        admin_mainLayout.setHorizontalGroup(
            admin_mainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_mainLayout.createSequentialGroup()
                .addComponent(admin_sidetab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(admin_multipanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        admin_mainLayout.setVerticalGroup(
            admin_mainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_sidetab, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
            .addComponent(admin_multipanel, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(admin_main, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(admin_main, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void admin_mouseclicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admin_mouseclicked
        if (evt.getSource()== admin_tab_welcome){
            admin_panel_welcome.setVisible(true);
            admin_panel_library.setVisible(false);
            admin_panel_rent.setVisible(false);
            admin_panel_returnbook.setVisible(false);
            admin_panel_user.setVisible(false);
            admin_panel_staff.setVisible(false);
        }
        if (evt.getSource()== admin_tab_library){
            admin_panel_welcome.setVisible(false);
            admin_panel_library.setVisible(true);
            admin_panel_rent.setVisible(false);
            admin_panel_returnbook.setVisible(false);
            admin_panel_user.setVisible(false);
            admin_panel_staff.setVisible(false);
        }
        if (evt.getSource()== admin_tab_rent){
            admin_panel_welcome.setVisible(false);
            admin_panel_library.setVisible(false);
            admin_panel_rent.setVisible(true);
            admin_panel_returnbook.setVisible(false);
            admin_panel_user.setVisible(false);
            admin_panel_staff.setVisible(false);
        }
        if (evt.getSource()== admin_tab_return){
            admin_panel_welcome.setVisible(false);
            admin_panel_library.setVisible(false);
            admin_panel_rent.setVisible(false);
            admin_panel_returnbook.setVisible(true);
            admin_panel_user.setVisible(false);
            admin_panel_staff.setVisible(false);
        }
        if (evt.getSource()== admin_tab_user){
            admin_panel_welcome.setVisible(false);
            admin_panel_library.setVisible(false);
            admin_panel_rent.setVisible(false);
            admin_panel_returnbook.setVisible(false);
            admin_panel_user.setVisible(true);
            admin_panel_staff.setVisible(false);
        }
        if (evt.getSource()== admin_tab_staff){
            admin_panel_welcome.setVisible(false);
            admin_panel_library.setVisible(false);
            admin_panel_rent.setVisible(false);
            admin_panel_returnbook.setVisible(false);
            admin_panel_user.setVisible(false);
            admin_panel_staff.setVisible(true);
        }
        if (evt.getSource()== admin_tab_logout){
            new login().setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_admin_mouseclicked

    private void admin_mouseentered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admin_mouseentered
        if (evt.getSource()== admin_tab_library){
            admin_tab_library.setBackground(new Color(255,204,0));
        }
        if (evt.getSource()== admin_tab_rent){
            admin_tab_rent.setBackground(new Color(255,204,0));
        }
        if (evt.getSource()== admin_tab_return){
            admin_tab_return.setBackground(new Color(255,204,0));
        }
        if (evt.getSource()== admin_tab_user){
            admin_tab_user.setBackground(new Color(255,204,0));
        }
        if (evt.getSource()== admin_tab_staff){
            admin_tab_staff.setBackground(new Color(255,204,0));
        }
        if (evt.getSource()== admin_tab_logout){
            admin_tab_logout.setBackground(new Color(255,204,0));
        }
    }//GEN-LAST:event_admin_mouseentered

    private void admin_mouseexited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admin_mouseexited
        if (evt.getSource()== admin_tab_library){
            admin_tab_library.setBackground(new Color(255,153,0));
        }
        if (evt.getSource()== admin_tab_rent){
            admin_tab_rent.setBackground(new Color(255,153,0));
        }
        if (evt.getSource()== admin_tab_return){
            admin_tab_return.setBackground(new Color(255,153,0));
        }
        if (evt.getSource()== admin_tab_user){
            admin_tab_user.setBackground(new Color(255,153,0));
        }
        if (evt.getSource()== admin_tab_staff){
            admin_tab_staff.setBackground(new Color(255,153,0));
        }
        if (evt.getSource()== admin_tab_logout){
            admin_tab_logout.setBackground(new Color(255,153,0));
        }
    }//GEN-LAST:event_admin_mouseexited

    private void admin_add_buttonimageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admin_add_buttonimageActionPerformed
        JFileChooser fileopen = new JFileChooser();
        int ret = fileopen.showDialog(null, "Choose file");
    }//GEN-LAST:event_admin_add_buttonimageActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admin_add_buttonadd;
    private javax.swing.JButton admin_add_buttondelete;
    private javax.swing.JButton admin_add_buttonedit;
    private javax.swing.JButton admin_add_buttonimage;
    private javax.swing.JTextField admin_add_id;
    private javax.swing.JLabel admin_add_image;
    private javax.swing.JTextField admin_add_name;
    private javax.swing.JTextField admin_add_price;
    private javax.swing.JTextField admin_add_quantity;
    private javax.swing.JTextField admin_add_type;
    private javax.swing.JPanel admin_liblrary_add;
    private javax.swing.JTable admin_library_order;
    private javax.swing.JTextField admin_library_search;
    private javax.swing.JPanel admin_main;
    private javax.swing.JPanel admin_multipanel;
    private javax.swing.JPanel admin_panel_library;
    private javax.swing.JPanel admin_panel_rent;
    private javax.swing.JPanel admin_panel_returnbook;
    private javax.swing.JPanel admin_panel_staff;
    private javax.swing.JPanel admin_panel_user;
    private javax.swing.JPanel admin_panel_welcome;
    private javax.swing.JScrollPane admin_rent_jscroll;
    private javax.swing.JTable admin_rent_order;
    private javax.swing.JTextField admin_rent_search;
    private javax.swing.JTextField admin_rent_search1;
    private javax.swing.JScrollPane admin_return_jscroll;
    private javax.swing.JTable admin_return_order;
    private javax.swing.JPanel admin_sidetab;
    private javax.swing.JPanel admin_staff_add;
    private javax.swing.JButton admin_staff_addbuttonadd;
    private javax.swing.JTextField admin_staff_addfirstname;
    private javax.swing.JTextField admin_staff_addlastname;
    private javax.swing.JPasswordField admin_staff_addpassword;
    private javax.swing.JTextField admin_staff_addusername;
    private javax.swing.JButton admin_staff_buttondelete;
    private javax.swing.JButton admin_staff_buttonedit;
    private javax.swing.JTable admin_staff_order;
    private javax.swing.JScrollPane admin_staff_scroll;
    private javax.swing.JTextField admin_staff_search;
    private javax.swing.JPanel admin_tab_empty1;
    private javax.swing.JPanel admin_tab_library;
    private javax.swing.JLabel admin_tab_librarylogo;
    private javax.swing.JPanel admin_tab_logout;
    private javax.swing.JLabel admin_tab_logoutlogo;
    private javax.swing.JPanel admin_tab_rent;
    private javax.swing.JLabel admin_tab_rentlogo;
    private javax.swing.JPanel admin_tab_return;
    private javax.swing.JLabel admin_tab_returnlogo;
    private javax.swing.JPanel admin_tab_staff;
    private javax.swing.JLabel admin_tab_stafflogo;
    private javax.swing.JPanel admin_tab_user;
    private javax.swing.JLabel admin_tab_userlogo;
    private javax.swing.JPanel admin_tab_welcome;
    private javax.swing.JLabel admin_tab_welcomelogo;
    private javax.swing.JLabel admin_txt_library;
    private javax.swing.JLabel admin_txt_logout;
    private javax.swing.JLabel admin_txt_rent;
    private javax.swing.JLabel admin_txt_return;
    private javax.swing.JLabel admin_txt_staff;
    private javax.swing.JLabel admin_txt_user;
    private javax.swing.JTable admin_user_order;
    private javax.swing.JScrollPane admin_user_scroll;
    private javax.swing.JTextField admin_user_search;
    private javax.swing.JLabel admin_welcome_bookrent;
    private javax.swing.JLabel admin_welcome_logo;
    private javax.swing.JLabel admin_welcome_name;
    private javax.swing.JLabel admin_welcome_welcome;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
